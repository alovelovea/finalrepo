export default function ProfileTag({ label }) {
  return <span className="profile-tag">#{label}</span>;
}