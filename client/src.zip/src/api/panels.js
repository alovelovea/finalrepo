// src/api/panels.js
import axiosInstance from "./axiosInstance";

// 패널 전체 조회
export const fetchPanels = async () => {
  const res = await axiosInstance.get("/api/v1/panels");
  return res.data;  // 백엔드 응답 형태에 맞게 조정
};

// 예: 특정 패널 상세
export const fetchPanelDetail = async (id) => {
  const res = await axiosInstance.get(`/api/v1/panels/${id}`);
  return res.data;
};
