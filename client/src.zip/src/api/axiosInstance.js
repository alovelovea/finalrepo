import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:8000",  // <-- 여기가 baseURL
  withCredentials: true,
});

export default axiosInstance;
